# python-menengah
Tutorial python tingkat menengah di Jago Ngoding
