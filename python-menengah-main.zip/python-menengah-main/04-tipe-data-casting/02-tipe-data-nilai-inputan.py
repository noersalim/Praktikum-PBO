usia = input('Masukkan usia anda: ')

print(type(usia))