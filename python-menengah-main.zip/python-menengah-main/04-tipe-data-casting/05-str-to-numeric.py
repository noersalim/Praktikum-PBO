panjang = int(input('Masukkan panjang: '))
lebar = float(input('Masukkan lebar: '))

print('Luas =', panjang * lebar)

print("*" * 20)

print(int(5.6))
print(float(5))