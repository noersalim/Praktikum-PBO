panjang = input('Masukkan panjang: ')
lebar = input('Masukkan lebar: ')

print('Luas =', panjang * lebar)