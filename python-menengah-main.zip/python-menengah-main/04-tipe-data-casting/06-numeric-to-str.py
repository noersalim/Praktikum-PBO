nama = 'Wudi'
tahun_lahir = 2000

print(nama + ' lahir di tahun ' + str(tahun_lahir))