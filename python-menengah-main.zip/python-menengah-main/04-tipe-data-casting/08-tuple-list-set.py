# list ke tuple dan ke set
listHuruf = ['a', 'b', 'c', 'c']

print(listHuruf)
print(tuple(listHuruf))
print(set(listHuruf))

print('*' * 25)

# tuple ke list dan ke set
tplBuah = ('Mangga', 'Jambu')

print(tplBuah)
print(list(tplBuah))
print(set(tplBuah))

print('*' * 25)


# set ke list dan ke tuple
setAngka = {1, 3, 5, 5}

print(setAngka)
print(list(setAngka))
print(tuple(setAngka))

