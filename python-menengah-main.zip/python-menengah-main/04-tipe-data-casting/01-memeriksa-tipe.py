nama = 'Budi'
usia = 20
lajang = True

print(type(nama))
print(type(usia))
print(type(lajang))