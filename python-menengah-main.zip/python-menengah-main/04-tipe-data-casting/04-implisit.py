a = 10 / 2
print(type(a))

b = 1 / 2
print(type(b))

print('*' * 20)

c = 10 + 5
print(type(c))

d = 10 + 5.0
print(type(d))

e = 10.5 - 3
print(type(e))

print('*' * 20)

kata = 'Jeruk ' * 5
print(kata)
print(type(kata))

print('*' * 20)
