nama_depan = 'Renza'
nama_belakang = 'Ilhami'

nama_lengkap = nama_depan + nama_belakang

print(nama_lengkap) # output: RenzaIlhami

nama_lengkap = nama_depan + ' ' + nama_belakang

print(nama_lengkap) # output: Renza Ilhami

print('Sekarang tahun: ' + str(2021))