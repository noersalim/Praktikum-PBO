email_1 = 'presiden@gmail.com'
email_2 = 'presiden@outlook.com'

print(email_1.endswith('gmail.com')) # True
print(email_2.endswith('gmail.com')) # False