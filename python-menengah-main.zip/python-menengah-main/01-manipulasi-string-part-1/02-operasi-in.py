berita = 'Ramai-ramai developer di seluruh dunia mulai menggunakan \
  teks editor masa kini seperti Visual Studio Code, \
  atom, sublime text, dan lain sebagainya.'

print('sublime text' in berita) # output: True
print('notepad++' in berita) # output: False