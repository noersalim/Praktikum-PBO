print(len('Indonesia'))
print(len('Malaysia'))