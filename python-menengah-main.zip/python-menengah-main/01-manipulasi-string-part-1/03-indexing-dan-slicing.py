nama = 'Lendis Fabri'
print(nama[4]) # output: i
print(nama[7]) # output: F
print(nama[-1]) # output: i
print(nama[-3]) # output: b

print('\n', ('-' * 10), '\n')

judul = 'Pelajaran Matematika Untuk SD'

print(judul[0:5]) # output: Pelaj
print(judul[:10]) # output: Pelajaran 
print(judul[10:15]) # output: Matem
print(judul[-1:-3]) # output: 
print(judul[:-3]) # output: Pelajaran Matematika Untuk
print(judul[-5:]) # output: uk SD





