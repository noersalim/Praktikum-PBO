# print("Dia berkata: "Pergilah!"")
print('Dia berkata: "Pergilah!"')

# menggunakan petik satu
print('Aku menimpali: "Apakah kau ingin aku \'angkat kaki\'?!"')

# menggunakan petik dua
print("Aku menimpali: \"Apakah kau ingin aku 'angkat kaki'?!\"")

print('\\(^_^ \) (/ -_-/)')
