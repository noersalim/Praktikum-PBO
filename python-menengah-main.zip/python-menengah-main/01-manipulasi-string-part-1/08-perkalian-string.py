print('----------') # output: ----------
print('-' * 10) # ouput: ----------