from Orang import Orang

class Pekerja (Orang):
    pass
