from Orang import Orang
from Pekerja import Pekerja
from Pelajar import Pelajar

andi = Orang('Andi', 'Surabaya')
andi.perkenalan()

deni = Pelajar('Deni', 'Makassar')
deni.perkenalan()

budi = Pekerja('Budi', 'Pontianak')
budi.perkenalan()
