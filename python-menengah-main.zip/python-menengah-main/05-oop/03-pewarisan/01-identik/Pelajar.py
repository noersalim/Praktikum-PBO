from Orang import Orang

class Pelajar (Orang):
    pass