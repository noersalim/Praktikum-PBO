from Orang import Orang

class Pekerja (Orang):

    def __init__ (self, nama, asal):
        self.nama = nama
        self.asal = asal