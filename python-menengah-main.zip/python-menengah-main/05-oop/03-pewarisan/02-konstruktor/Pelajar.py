from Orang import Orang

class Pelajar (Orang):

    def __init__ (self, nama, asal):
        self.nama = nama
        self.asal = asal
