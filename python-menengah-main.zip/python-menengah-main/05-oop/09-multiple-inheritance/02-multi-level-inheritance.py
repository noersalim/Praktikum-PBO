class Induk:
  pass

class Turunan1(Induk):
  pass

class Turunan2(Turunan1):
  pass