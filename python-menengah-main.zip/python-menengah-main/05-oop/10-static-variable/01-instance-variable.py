class Mahasiswa:
  def __init__(self, nama):
    self.nama = nama

budi = Mahasiswa('Budi')
andi = Mahasiswa('Andi')

print(budi.nama)
print(andi.nama)