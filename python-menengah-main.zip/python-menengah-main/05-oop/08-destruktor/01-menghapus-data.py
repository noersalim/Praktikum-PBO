a = 3

del a