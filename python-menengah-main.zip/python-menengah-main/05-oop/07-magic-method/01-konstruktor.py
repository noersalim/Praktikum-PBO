class HaloDunia:

  def __init__(self):
    print('Halo dunia')

# buat instan
a = HaloDunia()
b = HaloDunia()