class Mahasiswa:
  """
  Kelas ini digunakan untuk mendefinisikan
  objek Mahasiswa di kehidupan nyata
  """

print(Mahasiswa.__doc__)