# kelas kucing sebagai "definisi"
class Kucing:
  warna = None
  usia = None

# membangun instance/variabel sebagai "objek nyata"
kucing1 = Kucing()
kucing1.warna = "hitam"
kucing1.usia = "3 bulan"

kucing2 = Kucing()
kucing2.warna = "putih"
kucing2.usia = "2 bulan"

kucing3 = Kucing()
kucing3.warna = "kuning"
kucing3.usia = "3.5 bulan"

print(kucing1.warna, kucing1.usia)
print(kucing2.warna, kucing2.usia)
print(kucing3.warna, kucing3.usia)