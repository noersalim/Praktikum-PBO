paragraf = 'Baru-baru ini telah ditemukan sebuah meteor di suatu sungai'
x = paragraf.count('di')

print(f'Kata "di" muncul sebanyak {x} kali')