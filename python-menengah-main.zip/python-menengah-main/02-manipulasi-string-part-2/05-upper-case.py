print('halo selamat pagi!'.upper())
print('Halo Selamat Siang!'.upper())

salam = "السلام عليكم"

print(salam)
print(salam.upper())