angka = '12345'

print('Index angka 3:', angka.find('3'))
print('Index angka 45:', angka.find('45'))
print('Index angka 35:', angka.find('35'))