print('APA KABAR?'.lower())
print('Lagi Dimana?'.lower())