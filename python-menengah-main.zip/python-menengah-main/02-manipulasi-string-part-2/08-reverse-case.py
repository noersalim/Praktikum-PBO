print('Indonesia Adalah Negara Kepulauan'.swapcase())
print('aKu cInTa NeGeRiKu'.swapcase())