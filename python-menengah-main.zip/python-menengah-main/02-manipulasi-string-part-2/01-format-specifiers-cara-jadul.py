template = 'Halo, saya %s dari %s'

print(template % ('Lendis Fabri', 'Indonesia'))
