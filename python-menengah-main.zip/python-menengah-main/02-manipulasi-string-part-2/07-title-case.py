print('daun tidak pernah membenci angin'.title())
print('LASKAR PELANGI'.title())