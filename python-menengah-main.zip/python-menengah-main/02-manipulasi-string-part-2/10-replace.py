ibu_kota = 'Jakarta'

print(ibu_kota.replace('a', 'i'))
print(ibu_kota.replace('kar', '🦖'))

# replace a dengan teks kosong
print(ibu_kota.replace('a', ''))