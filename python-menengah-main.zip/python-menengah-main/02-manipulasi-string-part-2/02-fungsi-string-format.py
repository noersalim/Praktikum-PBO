template = 'Halo, saya {nama} dari {asal}'
template_2 = 'Saya suka makan {} dan minum {}'

print(template.format(nama = 'Lendis Fabri', asal = 'Indonesia'))
# Halo, saya Lendis Fabri dari Indonesia
print(template_2.format('Nasi Goreng', 'air putih'))
# Saya suka makan Nasi Goreng dan minum air putih
