nama = 'Lendis Fabri'
asal = 'Indonesia'

print(f'Perkenalkan saya {nama} dari {asal} 😎')