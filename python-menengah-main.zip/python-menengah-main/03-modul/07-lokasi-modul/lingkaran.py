def luas():
  pass