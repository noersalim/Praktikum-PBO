import lingkaran

print(lingkaran.__file__)