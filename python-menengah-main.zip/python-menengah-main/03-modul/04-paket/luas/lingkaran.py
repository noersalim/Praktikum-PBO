def luas_lingkaran(radius):
  return 22 / 7 * radius * radius
  