def luas_segitiga (alas, tinggi):
  return 0.5 * alas * tinggi
  