def volume_kubik ():
  pass