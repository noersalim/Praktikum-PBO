def volume_bola():
  pass