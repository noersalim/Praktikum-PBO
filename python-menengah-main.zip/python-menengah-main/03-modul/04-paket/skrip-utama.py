from luas.segitiga import luas_segitiga
from luas import lingkaran, persegi
from volume.kubik import volume_kubik
import volume.bola
from volume.trapesium import *

# panggil fungsi masing-masing  