bidang = 'lingkaran'

if bidang == 'lingkaran':
  from lingkaran import luas
elif bidang == 'persegi':
  from persegi import luas

# hitung luas
print(luas(20))