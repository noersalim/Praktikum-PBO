from matematika import *

print(luas_persegi(20))
print(luas_lingkaran(10))
print(_luas_segitiga(20, 10))