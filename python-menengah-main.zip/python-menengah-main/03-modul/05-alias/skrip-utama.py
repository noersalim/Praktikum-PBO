from persegi import luas as luas_persegi
from lingkaran import luas as luas_lingkaran

print(luas_persegi(10))
print(luas_lingkaran(21))