def luas (sisi):
  return sisi * sisi