def luas (radius):
  return 22 / 7 * radius * radius