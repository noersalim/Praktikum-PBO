pi = 22 / 7

def luas_persegi (sisi):
  return sisi * sisi

def luas_lingkaran (radius):
  return pi * radius * radius

