import matematika

print("PI:", matematika.pi)
print(matematika.luas_lingkaran(radius=21))
print(matematika.luas_persegi(sisi=12))