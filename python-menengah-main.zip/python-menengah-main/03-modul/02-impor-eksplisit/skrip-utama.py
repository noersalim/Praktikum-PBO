from matematika import luas_persegi, luas_lingkaran

print(luas_persegi(20))
print(luas_lingkaran(10))
