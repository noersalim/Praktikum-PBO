import math
import datetime

print('Tanggal dan waktu sekarang: ', datetime.datetime.now())
print('Nilai konstanta pi: ', math.pi)